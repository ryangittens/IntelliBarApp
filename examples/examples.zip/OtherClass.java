public class OtherClass {
    public void anotherMethod() {
        System.out.println("OtherClass.anotherMethod()");
    }
    public int intField = 6;
    public String stringField = "Testing";
}
