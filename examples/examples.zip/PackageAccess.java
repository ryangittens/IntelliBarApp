package com.mycompany;

import java.applet.Applet;

public class PackageAccess extends Applet {
}
