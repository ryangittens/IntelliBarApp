package com.mycompany;

public class MyClass {
    public static int staticField = 5;

    public static void staticMethod() {
        System.out.println("MyClass.staticMethod()");
    }

    public void instanceMethod() {
        System.out.println("MyClass.instanceMethod()");
    }
}
