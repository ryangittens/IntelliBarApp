import java.applet.Applet;
public class FieldAccess extends Applet {
    public int intField = 5;
    public String stringField = "Hello";
    public OtherClass otherField = new OtherClass();
}
